function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-6xl font-bold text-white tracking-tight">
          PUZZLE ME THIS
        </h1>
        <div className="mt-6 space-y-2">
          <p className="text-2xl text-amber-400 font-semibold">
            (DAY 394)
          </p>
          <p className="text-3xl text-red-500 font-bold tracking-wider">
            LEVEL: HARD
          </p>
        </div>
      </div>
    </div>
  );
}

export default App;
